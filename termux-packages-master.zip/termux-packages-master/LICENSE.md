# License for package patches

The scripts and patches to build each package is licensed under the same license as
the actual package (so the patches and scripts to build bash are licensed under
the same license as bash, while the patches and scripts to build python are licensed
under the same license as python).

# License for the build infrastructure

For build infrastructure outside the `packages/` folder the license is [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0).
