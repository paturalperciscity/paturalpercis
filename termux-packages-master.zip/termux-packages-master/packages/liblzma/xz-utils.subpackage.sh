TERMUX_SUBPKG_INCLUDE="bin/ share/man/man1/"
TERMUX_SUBPKG_DESCRIPTION="XZ-format compression tools"
TERMUX_SUBPKG_DEPENDS="liblzma"
