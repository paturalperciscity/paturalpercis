TERMUX_SUBPKG_INCLUDE="bin/"
TERMUX_SUBPKG_DESCRIPTION="New zlib compatible compressor tools"
