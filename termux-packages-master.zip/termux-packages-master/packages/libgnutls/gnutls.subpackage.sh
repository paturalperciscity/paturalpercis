TERMUX_SUBPKG_INCLUDE="bin/ share/man/man1/"
TERMUX_SUBPKG_DESCRIPTION="Commandline utilities for interfacing with the gnutls library"
TERMUX_SUBPKG_DEPENDS="libgnutls"
