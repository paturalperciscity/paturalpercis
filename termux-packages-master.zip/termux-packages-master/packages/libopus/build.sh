TERMUX_PKG_HOMEPAGE=https://www.opus-codec.org/
TERMUX_PKG_DESCRIPTION="Reference implementation of the Opus codec"
TERMUX_PKG_LICENSE="BSD 3-Clause"
TERMUX_PKG_VERSION=1.3.1
TERMUX_PKG_SHA256=65b58e1e25b2a114157014736a3d9dfeaad8d41be1c8179866f144a2fb44ff9d
TERMUX_PKG_SRCURL=https://archive.mozilla.org/pub/opus/opus-${TERMUX_PKG_VERSION}.tar.gz
