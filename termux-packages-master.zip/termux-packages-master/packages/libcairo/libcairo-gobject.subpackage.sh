TERMUX_SUBPKG_INCLUDE="lib/libcairo-gobject.so*"
TERMUX_SUBPKG_DESCRIPTION="GObject bindings for cairo"
TERMUX_SUBPKG_DEPENDS="glib,libcairo"
