TERMUX_PKG_HOMEPAGE=http://libpipeline.nongnu.org/
TERMUX_PKG_DESCRIPTION="C library for manipulating pipelines of subprocesses in a flexible and convenient way"
TERMUX_PKG_LICENSE="GPL-2.0"
TERMUX_PKG_VERSION=1.5.1
TERMUX_PKG_SHA256=d633706b7d845f08b42bc66ddbe845d57e726bf89298e2cee29f09577e2f902f
TERMUX_PKG_SRCURL=http://download.savannah.gnu.org/releases/libpipeline/libpipeline-${TERMUX_PKG_VERSION}.tar.gz
