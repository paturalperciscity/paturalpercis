TERMUX_SUBPKG_INCLUDE="bin/ share/man/man1/ share/man/man8"
TERMUX_SUBPKG_DESCRIPTION="Development utilities for International Components for Unicode"
TERMUX_SUBPKG_DEPENDS="libicu"
