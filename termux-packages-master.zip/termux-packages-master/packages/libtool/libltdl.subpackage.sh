TERMUX_SUBPKG_INCLUDE="lib/libltdl.so"
TERMUX_SUBPKG_DESCRIPTION="Library for dlopening libraries"
TERMUX_SUBPKG_CONFLICTS="libtool (<= 2.4.6-3)"
