TERMUX_SUBPKG_DESCRIPTION="Simple, extensible, embeddable programming language"
TERMUX_SUBPKG_DEPENDS="readline"
TERMUX_SUBPKG_INCLUDE="bin/ share/man/man1/"
