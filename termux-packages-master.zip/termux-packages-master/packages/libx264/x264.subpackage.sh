TERMUX_SUBPKG_INCLUDE=bin
TERMUX_SUBPKG_DESCRIPTION="Commandline video encoder for the H.264/MPEG-4 AVC format"
