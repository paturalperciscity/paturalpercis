TERMUX_SUBPKG_INCLUDE="bin/xsltproc share/man/man1/xsltproc.1.gz"
TERMUX_SUBPKG_DESCRIPTION="XSLT command line processor"
TERMUX_SUBPKG_DEPENDS="libxslt"
