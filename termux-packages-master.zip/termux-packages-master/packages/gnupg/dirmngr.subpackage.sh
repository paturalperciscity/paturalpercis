TERMUX_SUBPKG_INCLUDE="bin/dirmngr bin/dirmngr-client share/man/man8/dirmngr.8.gz share/man/man1/dirmngr-client.1.gz"
TERMUX_SUBPKG_DESCRIPTION="Server for managing certificate revocation lists"
TERMUX_SUBPKG_DEPENDS="gnupg (>= 2.2.9-1), libgnutls, resolv-conf"
