TERMUX_SUBPKG_INCLUDE="bin/ etc/ lib/libcli.so* lib/libprotocol-*.so* lib/librtp.so* lib/pulse-${TERMUX_PKG_VERSION}/ share/"
TERMUX_SUBPKG_DESCRIPTION="A featureful, general-purpose sound server"
TERMUX_SUBPKG_DEPENDS="libpulseaudio"
TERMUX_SUBPKG_CONFFILES="etc/pulse/client.conf etc/pulse/daemon.conf etc/pulse/default.pa etc/pulse/system.pa"
