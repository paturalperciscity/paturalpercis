TERMUX_SUBPKG_INCLUDE="bin/rdiff share/man/man1/rdiff.1.gz"
TERMUX_SUBPKG_DESCRIPTION="Remote incremental backup"
TERMUX_SUBPKG_DEPENDS="librsync,libpopt"
