TERMUX_SUBPKG_INCLUDE="bin/ lib/libprotobuf-lite.so* lib/libprotoc.so*"
TERMUX_SUBPKG_DESCRIPTION="Compiler for protocol buffer definition files"
TERMUX_SUBPKG_DEPENDS="libprotobuf"

