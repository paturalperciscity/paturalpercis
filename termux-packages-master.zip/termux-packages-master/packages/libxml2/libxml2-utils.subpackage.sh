TERMUX_SUBPKG_INCLUDE="bin/xmllint bin/xmlcatalog share/man/man1/xmllint.1.gz share/man/man1/xmlcatalog.1.gz"
TERMUX_SUBPKG_DESCRIPTION="XML utilities"
TERMUX_SUBPKG_DEPENDS="libxml2"
