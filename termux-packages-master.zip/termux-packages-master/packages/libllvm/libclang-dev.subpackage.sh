TERMUX_SUBPKG_INCLUDE="lib/libLLVM*.a lib/libclang*.a lib/LTO.so include/clang"
TERMUX_SUBPKG_DESCRIPTION="C language frontend library for LLVM"
TERMUX_SUBPKG_DEPENDS="libllvm"
