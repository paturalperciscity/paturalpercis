TERMUX_SUBPKG_INCLUDE="lib/clang lib/libclang.so"
TERMUX_SUBPKG_DESCRIPTION="C language frontend library for LLVM"
TERMUX_SUBPKG_DEPENDS="libllvm"
