TERMUX_SUBPKG_INCLUDE="bin/ share/man/man1/"
TERMUX_SUBPKG_DESCRIPTION="Color management utilities"
TERMUX_SUBPKG_DEPENDS="littlecms, libtiff"
