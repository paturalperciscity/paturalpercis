TERMUX_SUBPKG_INCLUDE="bin/ share/man/man1/"
TERMUX_SUBPKG_DESCRIPTION="Programs for manipulating JPEG files"
TERMUX_SUBPKG_DEPENDS="libjpeg-turbo"
