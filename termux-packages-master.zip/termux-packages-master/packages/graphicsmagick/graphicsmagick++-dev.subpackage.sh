TERMUX_SUBPKG_INCLUDE="include/GraphicsMagick/Magick++"
TERMUX_SUBPKG_DESCRIPTION="Development files for graphicsmagick++"
TERMUX_SUBPKG_DEPENDS="graphicsmagick++"
