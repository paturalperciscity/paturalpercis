TERMUX_PKG_HOMEPAGE=https://www.netfilter.org/projects/libmnl/
TERMUX_PKG_DESCRIPTION="a minimalistic user-space library oriented to Netlink developers"
TERMUX_PKG_LICENSE="LGPL-2.1"
TERMUX_PKG_VERSION=1.0.4
TERMUX_PKG_SRCURL=https://netfilter.org/projects/libmnl/files/libmnl-${TERMUX_PKG_VERSION}.tar.bz2
TERMUX_PKG_SHA256=171f89699f286a5854b72b91d06e8f8e3683064c5901fb09d954a9ab6f551f81
