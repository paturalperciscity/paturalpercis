TERMUX_PKG_HOMEPAGE=https://www.gnu.org/software/ddrescue/
TERMUX_PKG_DESCRIPTION="GNU data recovery tool"
TERMUX_PKG_LICENSE="GPL-3.0"
TERMUX_PKG_VERSION=1.24
TERMUX_PKG_SHA256=4b5d3feede70e3657ca6b3c7844f23131851cbb6af0cecc9721500f7d7021087
TERMUX_PKG_SRCURL=https://mirrors.kernel.org/gnu/ddrescue/ddrescue-${TERMUX_PKG_VERSION}.tar.lz
