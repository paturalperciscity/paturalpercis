TERMUX_PKG_HOMEPAGE=http://software.schmorp.de/pkg/libev.html
TERMUX_PKG_DESCRIPTION="Full-featured and high-performance event loop library"
TERMUX_PKG_LICENSE="BSD 2-Clause"
TERMUX_PKG_VERSION=4.25
TERMUX_PKG_SHA256=78757e1c27778d2f3795251d9fe09715d51ce0422416da4abb34af3929c02589
TERMUX_PKG_SRCURL=https://fossies.org/linux/misc/libev-$TERMUX_PKG_VERSION.tar.gz
