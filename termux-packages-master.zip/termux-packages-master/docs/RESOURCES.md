# External Resources Links

- [Android changes for NDK developers](https://android.googlesource.com/platform/bionic/+/master/android-changes-for-ndk-developers.md)

- [Linux From Scratch](http://www.linuxfromscratch.org/lfs/view/stable/)

- [Beyond Linux From Scratch](http://www.linuxfromscratch.org/blfs/view/stable/)

- [OpenWrt](https://openwrt.org/) as an embedded Linx distribution contains [patches and build scripts](https://dev.openwrt.org/browser/packages)

- [Kivy recipes](https://github.com/kivy/python-for-android/tree/master/pythonforandroid/recipes) contains recipes for building packages for Android.
