# Gets uninstalled automatically due to no file in package?
TERMUX_PKG_HOMEPAGE=http://www.tldp.org/HOWTO/Software-Building-HOWTO.html
TERMUX_PKG_DESCRIPTION="Collection of packages to build Linux software"
TERMUX_PKG_VERSION=0.1
TERMUX_PKG_DEPENDS="clang, gawk, make, sed"
TERMUX_PKG_METAPACKAGE=yes
TERMUX_PKG_PLATFORM_INDEPENDENT=yes
